package br.com.remember.comments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
