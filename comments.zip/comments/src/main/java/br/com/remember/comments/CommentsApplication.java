package br.com.remember.comments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommentsApplication.class, args);

		System.out.println("");


		System.out.println("Aplication no ar YEEEEAAAHHH!!!!");
	}

}
