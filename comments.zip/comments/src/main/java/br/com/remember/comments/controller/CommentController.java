package br.com.remember.comments.controller;

import br.com.remember.comments.domain.Comment;
import br.com.remember.comments.repository.CommentRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Optional;

@RestController
@RequestMapping(path = "/comment")
public class CommentController {

    @Autowired
    private CommentRepository commentRepository;
    //private Comment comment;

    @PostMapping
    public ResponseEntity<Comment> criarComment(@RequestBody Comment comment){
        comment.setId(ObjectId.get());
        commentRepository.save(comment);
        return ResponseEntity.ok(comment);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Comment> pegarComment(@PathVariable("id") ObjectId id){
        Optional<Comment> comment = commentRepository.findById(id);
        if(comment.isPresent())
            return ResponseEntity.ok(comment.get());

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarComment(@PathVariable("id") ObjectId id){
        commentRepository.deleteById(id);
        return ResponseEntity.ok("Comentario deletado com sucesso");

    }

    @PostMapping("/update/{id}")
    public  ResponseEntity<Comment> atualizarComment(@RequestBody Comment commentAtualizado, @PathVariable("id") ObjectId id){
            commentAtualizado.setId(id);
            commentRepository.save(commentAtualizado);
            return ResponseEntity.ok(commentAtualizado);
    }
}
