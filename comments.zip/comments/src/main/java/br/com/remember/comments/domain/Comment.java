package br.com.remember.comments.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Document(collection = "comment")
public class Comment {

    @Id
    private ObjectId id;


    @JsonProperty
    private Long id_moment;

    @JsonProperty
    private Long id_user;

    @JsonProperty
    private LocalDate dateCommernt;

    @JsonProperty
    private String nomeUser;

    @JsonProperty
    private String conteudo;

    public Long getId_user() {
        return id_user;
    }

    public void setId_user(Long id_user) {
        this.id_user = id_user;
    }

    public LocalDate getDateCommernt() {
        return dateCommernt;
    }

    public void setDateCommernt(LocalDate dateCommernt) {
        this.dateCommernt = dateCommernt;
    }

    public String getNomeUser() {
        return nomeUser;
    }

    public void setNomeUser(String nomeUser) {
        this.nomeUser = nomeUser;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public Long getId_moment() {
        return id_moment;
    }

    public void setId_moment(Long id_moment) {
        this.id_moment = id_moment;
    }
}
